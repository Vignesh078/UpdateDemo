package createAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	   private Customer customer;
	   private double openingBalance;
	   private IAccountService accountService;
	   
	   
	@Before
	public void setUp() {
		customer=new Customer();
		openingBalance=1000;
		accountService=new AccountServiceImpl();
	}
	@Given("^For customer details$")
	public void for_customer_details() throws Throwable {
		customer.setFirstName("Vicky");
		customer.setLastName("Vignesh");
		Address address=new Address();
		address.setDoorNo("61/102");
		address.setCity("Chennai");
	   
	}

	@When("^Valid customer$")
	public void valid_customer() throws Throwable {
	   assertNotNull(customer);
	}

	@Then("^create new account$")
	public void create_new_account() throws Throwable {
	    Account account=accountService.createAccount(customer, openingBalance);
	    assertNotNull(account);
	    assertEquals(openingBalance, account.getOpeningBalance(),0.0);
	    assertEquals(1, account.getAccountNo());
	}

	@When("^valid openingBalance$")
	public void valid_openingBalance() throws Throwable {
	    assertTrue(openingBalance>=500);
	}
}