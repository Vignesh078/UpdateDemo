package org.cap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

	@Configuration
	@EnableWebMvc
	@EnableTransactionManagement
	@ComponentScan({"org.cap"})
	public class AppConfig {
	        @Bean
			public InternalResourceViewResolver getViewResolver() {
	        	InternalResourceViewResolver viewResolver=
	        			new InternalResourceViewResolver();
	        	viewResolver.setViewClass(JstlView.class);
	        	viewResolver.setPrefix("/WEB-INF/pages/");
	        	viewResolver.setSuffix(".jsp");
	        	return viewResolver;
	        }
	        @Bean
	        public LocalEntityManagerFactoryBean getEntityManagerFactoryBean() {
	        	LocalEntityManagerFactoryBean fBean=new LocalEntityManagerFactoryBean();
	        	fBean.setPersistenceUnitName("jpademo");
	        	return fBean;
	        	
	        }
	        @Bean
	        public JpaTransactionManager geTransactionManager() {
	        	JpaTransactionManager transmanager=new JpaTransactionManager();
	        	transmanager.setEntityManagerFactory(getEntityManagerFactoryBean().getObject());
	        	return transmanager;
	        }
	}


