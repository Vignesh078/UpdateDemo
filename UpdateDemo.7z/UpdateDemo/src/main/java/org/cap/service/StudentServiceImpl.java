package org.cap.service;

import java.util.List;

import org.cap.dao.StudentDao;
import org.cap.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("StudentService")
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao StudentDao;
	@Override
	public List<Student> getStudents() {
		
		return StudentDao.getStudents();
	}

}
