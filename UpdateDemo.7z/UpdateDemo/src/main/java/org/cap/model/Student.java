package org.cap.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	@GeneratedValue
	@Column(name="StudentID")
private int studentID;
	@Column(name="StudName")
private String studName;
	@Column(name="Location")
private String location;
	public Student() {
		
	}
	
	
	
	public Student(int studentID, String studName, String location) {
		super();
		this.studentID = studentID;
		this.studName = studName;
		this.location = location;
	}
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", studName=" + studName + ", location=" + location + "]";
	}

	
	
	
}
