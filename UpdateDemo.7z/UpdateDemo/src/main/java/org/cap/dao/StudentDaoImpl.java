package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;
@Transactional
@Repository("StudentDao")
public class StudentDaoImpl implements StudentDao {

@PersistenceContext
private EntityManager entityManager;
	@Override
	public List<Student> getStudents() {
        List<Student> students=entityManager.createQuery("from Student").getResultList();
		return students;
	}

}
