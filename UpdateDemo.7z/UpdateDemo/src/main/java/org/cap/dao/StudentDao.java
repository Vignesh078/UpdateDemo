package org.cap.dao;

import java.util.List;

import org.cap.model.Student;

public interface StudentDao {
public List<Student> getStudents();
}
